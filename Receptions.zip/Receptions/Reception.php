<?php
     include "home.php";
?>

<div id="wrapper">	
	<div class="container">
    <h2>Customer Details</h2>
    <form data-toggle="validator" class="form-horizontal" action="Reception.php"  method="post" autocomplete="off">    
	<div class="form-group">
      <label class="control-label col-sm-2" for="email">Customer Name:</label>
       <div class="col-sm-4">
        <input type="text" class="form-control" name="name" Id="name" placeholder="Enter CustomerName"  required>
       </div>
    </div>
		
		<div class="form-group">
      <label class="control-label col-sm-2" for="email">Address:</label>
       <div class="col-sm-4">
	    <textarea class="form-control" rows="5" id="address" name="address"  required></textarea>
       </div>
    </div>
	
	
	<div class="form-group">
      <label class="control-label col-sm-2" for="email">Purpose of Visit:</label>
       <div class="col-sm-4">   
	     <textarea class="form-control" rows="5" id="purpose" name="purpose" required>      </textarea>      
       </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="email">Mobile No:</label>
       <div class="col-sm-4">
	    <textarea class="form-control" rows="3" id="mobile" name="mobile"  required>      </textarea>        
       </div>
    </div>
	
	<div class="form-group">
      <label class="control-label col-sm-2" for="email">float no:</label>
       <div class="col-sm-4">
        <input type="text" class="form-control" name="float"  id="float"    required>
       </div>
    </div>
	
	<div class="form-group">
      <label class="control-label col-sm-2" for="email">Date:</label>
       <div class="col-sm-4">
        <input type="date" class="form-control" name="date"  id="date"    required>
       </div>
    </div>
	
    
    <div class="form-group">
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn  btn-primary" name="insert">INSERT</button>
		<button type="reset" class="btn  btn-primary" name="reset">Reset</button>
      </div>
    </div>
	 </form>
  

  <?php	
      
	  error_reporting(E_ALL);
     ini_set('display_errors', 1);
	  
	  
           if(isset($_POST['insert'])) 
		   {          
		     
               $name = $_POST['name']; 			  
		       $address = $_POST['address'];
		       $purpose=$_POST['purpose']; 	
               $mobile=$_POST['mobile'];			   
			   $float=$_POST['float']; 			  
			   $date=$_POST['date']; 			  
			   
            /*   print "$name";
			   print "$address";
               print "$purpose";
			   print "$mobile";
			   print "$float";
			   print "$date";  */
			   
			  
			   	require_once 'dbconnect.php';
				
			   $sql = "INSERT INTO tbl_customer_details (name,address,purpose,mobile_no,floatno,date) VALUES ('$name','$address','$purpose','$mobile','$float','$date');";      			 
			   $res = mysql_query($sql);		
		       if ($res)
		        {
    			  echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
		       }
    		  else 
			  {
			      echo "<script type='text/javascript'>alert('error while processing!')</script>";
		     }	
           
		   }        
   ?>	
	
 
</div> 
    </div>
    